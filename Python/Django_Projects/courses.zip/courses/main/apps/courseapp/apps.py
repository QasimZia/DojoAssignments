from django.apps import AppConfig


class CourseappConfig(AppConfig):
    name = 'courseapp'
