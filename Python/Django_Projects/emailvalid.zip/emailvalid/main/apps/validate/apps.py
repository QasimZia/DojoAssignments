from django.apps import AppConfig


class ValidateConfig(AppConfig):
    name = 'validate'
