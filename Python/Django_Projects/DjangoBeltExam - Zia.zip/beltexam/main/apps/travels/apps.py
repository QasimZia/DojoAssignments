from django.apps import AppConfig


class TravelsConfig(AppConfig):
    name = 'travels'
