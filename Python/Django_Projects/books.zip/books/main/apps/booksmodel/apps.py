from django.apps import AppConfig


class BooksmodelConfig(AppConfig):
    name = 'booksmodel'
