module WallHelper
end
