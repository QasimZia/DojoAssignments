FactoryGirl.define do
  factory :comment do
    content "MyString"
    user nil
    message nil
  end
end
