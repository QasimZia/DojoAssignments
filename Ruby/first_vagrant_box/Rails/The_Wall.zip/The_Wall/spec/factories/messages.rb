FactoryGirl.define do
  factory :message do
    post "This is a message"
    user nil
  end
end
